def week_number(year: int, month: int, day: int):
    pass


def main():
    assert week_number(2022, 1, 1) == 1


if __name__ == "__main__":
    main()
